---
name: commit
description: Stage all changes, write a clear commit message describing what changed and why, and push to the current branch. Use when the user says "commit", "save my work", or has just finished a working change.
---

# Commit

When invoked:

1. Run `git status` and `git diff` to see what actually changed. Make sure no secrets (`.env` files, keys, tokens) are about to be committed.
2. Stage all changes (`git add -A`).
3. Write a concise commit message: a short summary line describing *what* changed and *why*: specific, not generic. If there's meaningful detail, add a short body.
4. Commit, then push to the current branch.
5. If the push fails because of a conflict, do NOT force push, rebase, or reset. Pull, merge, resolve, then push normally, and tell the user what happened.
6. Never run anything that rewrites history or discards work without the user's explicit approval for that one action: force push, `reset --hard`, rebasing or amending pushed commits, `checkout -- .`, `restore .`, `stash drop`/`clear`, `clean -fd`, `branch -D`. Never skip checks with `--no-verify`.

Good messages: "fix login redirect on mobile Safari", "add email notification for updated docs".
Bad messages: "updates", "fixed stuff", "wip".
